// Run this in your browser console

document.addEventListener('scroll', () => {
  console.log('Scrolling...');
});

// See what happens when you scroll
