console.log(`This script is in: ${__dirname}`);
console.log(`The full path for this file is: ${__filename}`);
