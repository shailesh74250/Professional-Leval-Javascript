console.log(`Arguments are:\n${process.argv.join('\n')}`);
