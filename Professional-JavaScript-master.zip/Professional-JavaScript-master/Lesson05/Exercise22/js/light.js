let light = {};
light.state = true;
light.level = 0.5;

var log = function () {
   console.log(light);
};

export default log;
