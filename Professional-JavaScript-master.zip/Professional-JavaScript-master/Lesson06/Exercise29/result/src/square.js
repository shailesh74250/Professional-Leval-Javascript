const square = x => x * x;
console.log(square(5));
