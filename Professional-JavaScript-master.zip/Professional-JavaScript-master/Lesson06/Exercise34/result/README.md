Due to this exercise using a feature of git itself, the result cannot be saved to a repository.
