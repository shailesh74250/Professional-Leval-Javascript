console.log("I'm an npm package running from sample_npm");
