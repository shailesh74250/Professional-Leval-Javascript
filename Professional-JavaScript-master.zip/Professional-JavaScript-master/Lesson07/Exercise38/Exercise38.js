let singers = [];
singers.push('miku');
console.log(singers);

let food = new Array(3)
food.push('burger');
console.log(food);

singers.push('me');
console.log(singers);

singers.pop();
console.log(singers);

singers.unshift('rin')

console.log(singers);
